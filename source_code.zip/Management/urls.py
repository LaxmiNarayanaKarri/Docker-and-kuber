
from django.contrib import admin
from django.urls import path
from Management import views

urlpatterns = [
    path('ViewUser/',views.User_all_view),
    path('ViewPost/',views.Post_all_view),
    path('ViewProduct/',views.Product_all_view),


    path('admin/', admin.site.urls),


]
