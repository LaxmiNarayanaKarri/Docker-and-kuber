from django.http import JsonResponse
from .models import *
from .serializers import *
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404


@api_view(['GET', 'POST'])
def User_all_view(request):
    if request.method == 'GET':
        customers = User.objects.all()
        serialized = UserSerializer(customers, many=True)
        return JsonResponse(serialized.data, safe=False)
    elif request.method == 'POST':
        serialized = UserSerializer(data=request.data)
        if serialized.is_valid():
            serialized.save()
            return Response(serialized.data, status=status.HTTP_201_CREATED)
        return Response(serialized.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
def Post_all_view(request):
    if request.method == 'GET':
        customers = Post.objects.all()
        serialized = PostSerializer(customers, many=True)
        return JsonResponse(serialized.data, safe=False)
    elif request.method == 'POST':
        serialized = PostSerializer(data=request.data)
        if serialized.is_valid():
            serialized.save()
            return Response(serialized.data, status=status.HTTP_201_CREATED)
        return Response(serialized.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
def Product_all_view(request):
    if request.method == 'GET':
        customers = Product.objects.all()
        serialized = ProductSerializer(customers, many=True)
        return JsonResponse(serialized.data, safe=False)
    elif request.method == 'POST':
        serialized = ProductSerializer(data=request.data)
        if serialized.is_valid():
            serialized.save()
            return Response(serialized.data, status=status.HTTP_201_CREATED)
        return Response(serialized.errors, status=status.HTTP_400_BAD_REQUEST)


