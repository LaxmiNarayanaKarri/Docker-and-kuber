from rest_framework import serializers
from .models import *

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=['id','name','phonenumber']


class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model=Post
        fields=['id','subject','content']

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model=Product
        fields=['id','name','description']
