from django.db import models


class User(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=50)
    phonenumber = models.CharField(max_length=15)  # Adjusted to CharField


class Post(models.Model):
    id = models.IntegerField(primary_key=True)
    subject = models.CharField(max_length=50)
    content = models.TextField() # Adjusted field name to snake_case

class Product(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=50)
    description = models.TextField()

